/*********************************************
Main Driver for the Wumpus World Program
**********************************************/
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import java.util.Scanner;

public class WumpusDriver{
  public static void main(String[] args){
      //Create and invoke main menu object
      Menu menu = new Menu();
      menu.mainMenu();
    }
}
